package com.demo.cg.controller;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.demo.entity.Customer;
import com.cg.demo.exceptions.ODCNotFoundException;
import com.cg.demo.service.CustomerService;
@RestController
@RequestMapping("/customer")

public class CustomerController {
	@Autowired
	private CustomerService customerService;
	
	@PostMapping(" ")
	public  Customer addCustomer(@RequestBody Customer customer) {
	 Customer cust=customerService.addCustomer(customer);
	return cust;
	}
	@DeleteMapping("/deletecustomer/{id}")
	public void deletecustomer(@PathVariable int userId) {
		 customerService.deleteCustomer(userId);
	}

	@PutMapping("/customers/update/{userId,customer}")
	public ResponseEntity<Customer> updateEmployee(@PathVariable(value= "userId") int userId, @RequestBody Customer customer) throws ODCNotFoundException {
		Customer cust = customerService.getCustomer(userId).orElseThrow(()-> new ODCNotFoundException("Noo customer Found With this Id : "+userId));
		cust.setName(customer.getName());
		cust.setEmail(customer.getEmail());
		cust.setContactNo(customer.getContactNo());
		cust.setDob(customer.getDob());
		Customer updateCustomer = customerService.updateCustomer(1,cust);
		return ResponseEntity.ok(updateCustomer);
	}
	@GetMapping("/{userId}")
	public Customer find(@PathVariable int userId) {
	Optional<Customer> optCustomer=customerService.getCustomer(userId); 
	return optCustomer.orElse(null);
	}
	@GetMapping("")
	public List<Customer> getAllCustomers(){
		return customerService.getAllCustomers();
	}
	
}
