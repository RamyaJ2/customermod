package com.cg.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.demo.entity.Customer;

public interface CustomerRepository extends JpaRepository <Customer,Integer> {

}
