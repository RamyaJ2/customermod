package com.cg.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.demo.entity.Address;

public interface AddressRepository extends JpaRepository<Address,Long>{

}
