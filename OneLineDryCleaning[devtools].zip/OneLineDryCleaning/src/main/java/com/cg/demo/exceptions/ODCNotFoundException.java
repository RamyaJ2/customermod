package com.cg.demo.exceptions;

@SuppressWarnings("serial")
public class ODCNotFoundException extends Exception {
	
	public ODCNotFoundException(String message)
	{
		super(message);
	}

}
