package com.cg.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.demo.Repository.CustomerRepository;
import com.cg.demo.entity.Customer;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer addCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public void deleteCustomer(int userId) {
		customerRepository.deleteById(userId);

	}

	@Override
	public Customer updateCustomer(int userId, Customer customer) {
	if (customerRepository.findById(customer.getUserId()) != null) {
			return customerRepository.save(customer);
		} else {
			return null;

		}
	}

	@Override
	public Optional<Customer> getCustomer(int userId) {
		Optional<Customer> optcustomer = customerRepository.findById(userId);
		return optcustomer;
	}

	@Override
	public List<Customer> getAllCustomers() {
		List<Customer> allcustomers = customerRepository.findAll();
		return allcustomers;

	}

}
