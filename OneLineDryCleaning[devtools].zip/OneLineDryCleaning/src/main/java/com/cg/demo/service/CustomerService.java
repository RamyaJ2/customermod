package com.cg.demo.service;

import java.util.List;

import java.util.Optional;

import com.cg.demo.entity.Customer;

public interface CustomerService {
	Customer addCustomer(Customer customer);

	void deleteCustomer(int userId);

	Customer updateCustomer(int userId, Customer customer);

	Optional<Customer> getCustomer(int userId);

	List<Customer> getAllCustomers();
}
