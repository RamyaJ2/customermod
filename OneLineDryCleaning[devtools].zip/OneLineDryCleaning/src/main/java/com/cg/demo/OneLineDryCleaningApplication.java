package com.cg.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneLineDryCleaningApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneLineDryCleaningApplication.class, args);
	}

}
